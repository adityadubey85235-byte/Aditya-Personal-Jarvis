package com.aditya.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity implements TextToSpeech.OnInitListener {
    private static final int REQ_SPEECH = 101;
    private static final int REQ_AUDIO = 102;
    private static final int REQ_CAMERA = 103;
    private TextView statusText, transcriptText;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private boolean torchOn = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        statusText = findViewById(R.id.statusText);
        transcriptText = findViewById(R.id.transcriptText);
        tts = new TextToSpeech(this, this);
        Button listen = findViewById(R.id.listenButton);
        listen.setOnClickListener(v -> startListening());
        findViewById(R.id.torchButton).setOnClickListener(v -> toggleTorch());
        findViewById(R.id.settingsButton).setOnClickListener(v -> {
            startActivity(new Intent(Settings.ACTION_SETTINGS));
            respond("Theek hai bhai, Settings khol di.");
        });
    }

    @Override public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            int result = tts.setLanguage(new Locale("hi", "IN"));
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts.setLanguage(Locale.getDefault());
            }
            ttsReady = true;
        }
    }

    private void startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            respond("Bhai, is phone par speech recognition service available nahi hai.");
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
            return;
        }
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN");
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Bhai, command bol...");
        try { startActivityForResult(intent, REQ_SPEECH); }
        catch (ActivityNotFoundException e) { respond("Speech input app nahi mili, bhai."); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_SPEECH && resultCode == RESULT_OK && data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) {
                String command = results.get(0);
                transcriptText.setText("Tune bola: “" + command + "”");
                handleCommand(command.toLowerCase(Locale.ROOT));
            }
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_AUDIO && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) startListening();
        else if (requestCode == REQ_AUDIO) respond("Mic permission ke bina voice command nahi sun sakta, bhai.");
        else if (requestCode == REQ_CAMERA && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) setTorch(!torchOn);
        else if (requestCode == REQ_CAMERA) respond("Torch ke liye camera permission chahiye, bhai.");
    }

    private void handleCommand(String raw) {
        CommandParser.Result result = CommandParser.parse(raw);
        switch (result.action) {
            case TORCH_ON: setTorch(true); return;
            case TORCH_OFF: setTorch(false); return;
            case SETTINGS: startActivity(new Intent(Settings.ACTION_SETTINGS)); respond("Haan bhai, Settings khol di."); return;
            case YOUTUBE: openApp("com.google.android.youtube", "YouTube"); return;
            case CHROME: openApp("com.android.chrome", "Chrome"); return;
            case WHATSAPP: openApp("com.whatsapp", "WhatsApp"); return;
            case MAPS: openApp("com.google.android.apps.maps", "Google Maps"); return;
            case GMAIL: openApp("com.google.android.gm", "Gmail"); return;
            case CAMERA:
                try { startActivity(new Intent("android.media.action.IMAGE_CAPTURE")); respond("Camera kholne ki koshish kar raha hoon, bhai."); }
                catch (ActivityNotFoundException e) { respond("Camera app nahi mili, bhai."); }
                return;
            case GREETING: respond("Main badhiya hoon bhai! Tu bata, kya haal-chaal hain?"); return;
            case WEB_SEARCH:
                if (result.query.isEmpty()) { respond("Bhai, kya search karna hai?"); return; }
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(result.query)));
                startActivity(i); respond("Theek hai bhai, search khol di."); return;
            case UNKNOWN:
            default: respond("Bhai, ye command abhi set nahi hai. Apps khol sakta hoon, torch toggle kar sakta hoon aur web search kar sakta hoon.");
        }
    }

    private void openApp(String packageName, String appName) {
        Intent launch = getPackageManager().getLaunchIntentForPackage(packageName);
        if (launch != null) { startActivity(launch); respond("Haan bhai, " + appName + " khol diya."); }
        else respond(appName + " installed nahi hai ya phone par available nahi hai, bhai.");
    }

    private void toggleTorch() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
            return;
        }
        setTorch(!torchOn);
    }
    private void setTorch(boolean on) {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
            return;
        }
        try {
            CameraManager manager = (CameraManager) getSystemService(CAMERA_SERVICE);
            String[] ids = manager.getCameraIdList();
            for (String id : ids) {
                Boolean flash = manager.getCameraCharacteristics(id).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE);
                if (Boolean.TRUE.equals(flash)) {
                    manager.setTorchMode(id, on); torchOn = on;
                    respond(on ? "Torch on kar di, bhai." : "Torch off kar di, bhai."); return;
                }
            }
            respond("Is phone mein torch available nahi hai.");
        } catch (CameraAccessException | SecurityException e) {
            respond("Torch control nahi ho paya. Camera permission ya doosri app ka use check kar, bhai.");
        }
    }

    private void respond(String message) {
        statusText.setText(message);
        if (ttsReady) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "aditya_reply");
    }

    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}
