package com.aditya.assistant;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;

/** Lightweight animated cyan orb drawn directly on Canvas. */
public class OrbView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float pulse = 0.5f;
    private final ValueAnimator animator;
    public OrbView(Context c, AttributeSet a) {
        super(c, a); setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        animator = ValueAnimator.ofFloat(0f, 1f); animator.setDuration(1900); animator.setRepeatCount(ValueAnimator.INFINITE);
        animator.setRepeatMode(ValueAnimator.REVERSE); animator.setInterpolator(new AccelerateDecelerateInterpolator());
        animator.addUpdateListener(v -> { pulse = (float) v.getAnimatedValue(); invalidate(); });
    }
    @Override protected void onAttachedToWindow() { super.onAttachedToWindow(); animator.start(); }
    @Override protected void onDetachedFromWindow() { animator.cancel(); super.onDetachedFromWindow(); }
    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas); float cx=getWidth()/2f, cy=getHeight()/2f; float base=Math.min(getWidth(),getHeight())*.34f;
        paint.setShader(null); paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(2f); paint.setColor(0x6655DFFF);
        canvas.drawCircle(cx,cy,base*(1.35f+pulse*.12f),paint); canvas.drawCircle(cx,cy,base*1.52f,paint);
        paint.setStyle(Paint.Style.FILL); paint.setShader(new RadialGradient(cx-base*.15f,cy-base*.2f,base*(1.15f+pulse*.08f),new int[]{0xFFE9FFFF,0xFF48DFFF,0xFF1676C9,0x00106CC0},null,Shader.TileMode.CLAMP));
        canvas.drawCircle(cx,cy,base*(1.15f+pulse*.08f),paint); paint.setShader(null);
        paint.setColor(0xAA54DFFF); paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(1.4f);
        canvas.drawArc(cx-base*1.28f,cy-base*1.28f,cx+base*1.28f,cy+base*1.28f,205,100,false,paint);
    }
}
