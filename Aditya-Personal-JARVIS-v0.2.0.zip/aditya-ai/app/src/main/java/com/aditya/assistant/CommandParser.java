package com.aditya.assistant;

import java.util.Locale;

/** Offline, deterministic command matching. No network or personal data required. */
public final class CommandParser {
    public enum Action { TORCH_ON, TORCH_OFF, SETTINGS, YOUTUBE, CHROME, WHATSAPP, MAPS, GMAIL, CAMERA, WEB_SEARCH, GREETING, UNKNOWN }
    public static final class Result {
        public final Action action;
        public final String query;
        Result(Action action, String query) { this.action = action; this.query = query; }
    }
    private CommandParser() {}
    public static Result parse(String input) {
        String c = input == null ? "" : input.toLowerCase(Locale.ROOT).trim()
                .replace("aditya", "").replace("jarvis", "").trim();
        if (any(c, "torch on", "flashlight on", "torch chalu", "torch jalao", "टॉर्च चालू")) return new Result(Action.TORCH_ON, "");
        if (any(c, "torch off", "flashlight off", "torch band", "टॉर्च बंद")) return new Result(Action.TORCH_OFF, "");
        if (any(c, "settings", "setting kholo", "सेटिंग")) return new Result(Action.SETTINGS, "");
        if (any(c, "youtube", "यूट्यूब")) return new Result(Action.YOUTUBE, "");
        if (any(c, "chrome", "browser", "ब्राउज़र")) return new Result(Action.CHROME, "");
        if (any(c, "whatsapp", "व्हाट्सऐप")) return new Result(Action.WHATSAPP, "");
        if (any(c, "google maps", "maps", "मैप")) return new Result(Action.MAPS, "");
        if (any(c, "gmail", "जीमेल")) return new Result(Action.GMAIL, "");
        if (any(c, "camera", "कैमरा")) return new Result(Action.CAMERA, "");
        if (any(c, "hello", "kaise ho", "haal chaal", "kya haal", "नमस्ते", "नमस्कार") || c.equals("hi") || c.startsWith("hi ") || c.endsWith(" hi") || c.contains(" hi ")) return new Result(Action.GREETING, "");
        String query = c;
        for (String prefix : new String[]{"search for ", "search ", "google par ", "dhundo ", "ढूंढो ", "खोजो "}) {
            if (query.startsWith(prefix)) { query = query.substring(prefix.length()).trim(); break; }
        }
        if (any(c, "search ", "search for ", "google par ", "dhundo ", "ढूंढो ", "खोजो "))
            return new Result(Action.WEB_SEARCH, query);
        return new Result(Action.UNKNOWN, "");
    }
    private static boolean any(String value, String... candidates) {
        for (String candidate : candidates) if (value.contains(candidate)) return true;
        return false;
    }
}
