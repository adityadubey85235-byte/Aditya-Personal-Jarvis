package com.aditya.assistant;

import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class CommandParserTest {
    @Test public void recognizesHindiTorchOn() { assertEquals(CommandParser.Action.TORCH_ON, CommandParser.parse("टॉर्च चालू करो").action); }
    @Test public void recognizesSettingsWithWakeName() { assertEquals(CommandParser.Action.SETTINGS, CommandParser.parse("Aditya settings kholo").action); }
    @Test public void extractsSearchQuery() { assertEquals("weather in lucknow", CommandParser.parse("search weather in Lucknow").query); }
    @Test public void unknownCommandIsSafe() { assertEquals(CommandParser.Action.UNKNOWN, CommandParser.parse("do something magic").action); }
}
