# Aditya Personal JARVIS (starter v0.2.0)

A free, lightweight Android assistant starter based on the recovered Java/XML project. The interface has a dark cyan theme and a custom animated orb. Core command matching is offline and deterministic.

## Current features
- Tap-to-talk Hindi speech recognition through Android's configured recognition service (requires microphone permission and a compatible service).
- Hindi text-to-speech when the device has a supported voice installed.
- Opens supported apps, Android Settings, Camera and Google web search.
- Torch control with runtime camera permission.
- Custom animated orb; stops animating when the view is detached.
- Unit tests for core command parsing.
- GitHub Actions workflow builds a debug APK and uploads it as an artifact.

## Not implemented yet
- No conversational LLM provider is connected. No API keys are bundled.
- No always-on “Hey Aditya” wake word; tap-to-talk is used to avoid background microphone use and battery drain.
- No cloud memory or stored personal profile. This version does not persist conversations.
- Android may route speech recognition through an installed service; offline recognition depends on that service and downloaded language data.

## Build locally
Requires JDK 17, Android SDK platform 35 and Gradle 8.9. From this directory:

```bash
gradle testDebugUnitTest assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Build on a phone using GitHub Actions
1. Create a GitHub repository and upload the contents of this folder (not the enclosing folder) to the repository root.
2. Open the repository's **Actions** tab and enable workflows if prompted.
3. Run **Build Aditya AI APK** using **Run workflow**, or push a commit to `main`/`master`.
4. Open the completed workflow run and download the `aditya-ai-debug-apk` artifact. Unzip it to get `app-debug.apk`.
5. Install only if you trust the source; Android may ask permission to install apps from your browser/files app.

The APK is not signed for Play Store release. GitHub Actions needs internet access to download Gradle and Android SDK packages.
